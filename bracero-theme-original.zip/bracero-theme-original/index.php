<?php head(array('bodyclass'=>'home','title'=> 'Home')); ?>	

    <!-- <div id="primary">
    


            <p>In a partnership between George Mason University&#8217;s <a href="http://chnm.gmu.edu">Center for History and New Media</a>, the <a href="http://americanhistory.si.edu/">National Museum of American History</a>, the <a href="http://www.utep.edu/">University of Texas at El Paso</a>, and <a href="http://brown.edu">Brown University</a>, <em><?php echo settings('site_title'); ?></em> will grow to include sound files and transcripts of interviews with program participants, photographs, documents, and other files of interest. Users, which will include researchers, students, and others interested in the Bracero program, will be able to conduct searches using several different fields.</p> 

    </div> -->
    
    <!-- <div id="myomeka-button" class="home-button vcard">
		<p><a href="<?php// echo uri('myomeka'); ?>">Login</a> here to add your own notes and make a poster using items from the archive.</p>
		<div class="green-button">
		    <a href="<?php// echo uri('myomeka'); ?>">My Archive</a>
		 </div>
	</div> -->
    
	<!--<div id="contact-info" class="vcard home-button">
		<p>The Bracero History Archive is continuing to collect the stories of the Bracero program.</p>
		<div class="green-button">
		    <a href="<?php echo uri('contribution'); ?>">Tell Your Story</a>
		</div>
	</div>
	
	<div id="news-button" class="vcard home-button">
		<p>Check out news about the Bracero History Archive and the Smithsonian exhibit, Bittersweet Harvest.</p>
		<div class="green-button">
		    <a href="<?php echo uri('news'); ?>">Bracero History News</a>
		</div>
	</div>-->
	

	
<?php foot(); ?>