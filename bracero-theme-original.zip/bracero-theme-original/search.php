<?php head(array('body_class'=>'search','title'=> 'Search')); ?>	
<div id="primary">
	<h1>Search</h1>
<?php items_advanced_search(array('id'=>'search_form'),uri('items/browse')); ?>
	
</div>	
<?php foot(); ?>