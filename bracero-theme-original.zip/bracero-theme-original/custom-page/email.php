<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<base href="http://go.si.edu/site/" />
<title>Smithsonian Institution : Survey - Bracero Site signup</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="Content-Script-Type" content="text/javascript" />
<meta name="Keywords" content=" " />
<meta name="Description" content="" />
<script type="text/javascript" src="../js/utils.js"></script>
<script type="text/javascript" src="../js/CList.js"></script>
<script type="text/javascript" src="../js/CCallWrapper.js"></script>
<script type="text/javascript" src="../js/CSimpleObservable.js"></script>
<script type="text/javascript" src="../js/obs_comp.js"></script>
<link href="../css/themes/default.css" rel="stylesheet" type="text/css" />
<link href="../css/themes/alphacube.css" rel="stylesheet" type="text/css"/>
<link href="../css/UserGlobalStyle.css" rel="stylesheet" type="text/css" />
<link href="../css/CustomStyle.css" rel="stylesheet" type="text/css" />
<link href="../css/CustomWysiwygStyle.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="../js/user_wrapper.js"></script>
<meta name="CnvHeaderVersion" content="v5.0" />
<link rel="stylesheet" type="text/css" href="../css/ga-public.css" media="screen" />
<link rel="stylesheet" href="<?php echo css('screen'); ?>" type="text/css" media="screen" title="no title" charset="utf-8" />
<style type="text/css">
body {
	background-color: #336699;
}
#ga-container {
	width: 626px;
	margin-left: auto;
	margin-right: auto;
}
#ga-content {
	position: relative;
	top: 0;
	left: 0;
	margin: 0 auto;
	padding: 0;
	width: 100%;
}
#ga-footer {
	bottom: 0;
	margin: 0 auto;
	padding: 0;
	width: 626px;
	color: #800080;
	border-top: 4px solid #800080;
}
#ga-footer table {
	width: 100%;
	margin: 0 auto;
	padding: 0;
}
#ga-footer td {
	margin: 0;
	padding: 0;
	vertical-align: top;
	color: #000080;
}
#ga-header {
	top: 0;
	left: 0;
	margin: 0;
	padding: 0;
	width: 100%;
	background-color: #000000;
	color: #F6CA00;
	text-align: center;
}
.ga-footerImgAlign {
	vertical-align: bottom;
}
.ga-headerImgAlign {
	vertical-align: top;
	margin: 0;
	padding: 0;
	border-width: 0;
	border-style: none;
}
.ga-headerText {
	font-family: Verdana, "MS Trebuchet", Arial, sans-serif;
	font-size: 16px;
	font-weight: bold;
	color: #F6CA00;
	padding: 10px;
}
</style>
</head>
<body>
  	<div id="header">

		<div id="logo">
			<?php if($bodyclass=='home') { ?>
				<div class="padding">
			<?php } ?>
			<a id="logo-link" href="<?php echo uri(''); ?>"><img alt="Bracero Archive Logo" src="<?php if($bodyclass=='home') echo img('bracero-logo-lg.gif'); else echo img('bracero-logo.gif'); ?>" /></a>
			<?php if($bodyclass=='home') { ?>
			
			<div id="site-about">
				<p>The <em><?php echo settings('site_title'); ?></em> collects and makes available the oral histories and artifacts pertaining to the Bracero program, a guest worker initiative that spanned the years 1942-1964. Millions of Mexican agricultural workers crossed the border under the program to work in more than half of the states in America.</p>  
				
				<div id="buttons">
					<ul>
					<li><a href="<?php echo uri('items'); ?>">Browse the Archive</a></li>
					<!-- <li><a href="<?php echo uri(''); ?>">English</a></li> -->
					<li><a href="<?php echo uri('es')?>">Espa&ntilde;ol</a></li>
					</ul>
				</div>
			</div>
			

			
			
			<?php } if($bodyclass=='home') { ?>
				</div>
			<?php } ?>
		</div>			
		<div id="site-meta">
			<div id="login-status">
          <?php echo my_omeka_user_status(); ?>
			</div>
			

			<div id="search-box">
		    <?php echo simple_search(); ?>
		    <?php echo link_to_advanced_search(); ?>
			</div>

			

		</div>

	</div>
	
	<div id="sitenav">
		
		<ul>
			<?php echo nav(array('Archive' => uri('items'),'Teaching' => uri('teaching'),'History' => uri('#'),'Resources' => uri('#'),'About' => uri('about'),'Partners'=>uri('partners'))); ?>
		</ul>
	</div>
  <div id="content">
    <table bgcolor="#FFFFFF" width="626" cellpadding="8">
      <tr>
        <td><form method="post" action="http://go.si.edu/site/Survey">
            <div class="appArea">
              <table width="100%" border="0" cellspacing="4" cellpadding="0">
                <tr valign="top">
                  <td width="5%" class="req" align="right" nowrap="nowrap">&nbsp;</td>
                  <td><h3>Email me a reminder</h3></td>
                </tr>
                <tr valign="top">
                  <td width="5%" class="req" align="right" nowrap="nowrap">&nbsp;</td>
                  <td><p class="Explicit">Use this form to send yourself a link to the Bracero History Archive site for later viewing. The site features hundreds of images, stories, and other documents relating to the Bracero guest worker program from 1942-1964.</p>
                      
                      <p class="Explicit">Utilice este formulario para autoenviarse el enlace al archivo en la Web de historias orales de braceros para recorrerlo mas tarde. El sitio contine cientos de imagenes, historias, y demás documentos relacionados con el programa de trabajadores temporarios braceros de 1942 hasta 1964.</p>
                      
                    <table border="0" cellspacing="4" cellpadding="0">
                      <tr valign="top" style="display:none;">
                        <td><input name="3250_1720_2_1841" type="checkbox" class="checkbox" id="3250_1720_2_1841_1" value="1084" checked="checked"  />
                        </td>
                        <td><p>
                            <label for="3250_1720_2_1841_1" class="wrapable">Monthly Newsletter</label>
                          </p></td>
                      </tr>
                      <tr valign="top" style="display:none;">
                        <td><input type="checkbox" name="3250_1720_2_1841" id="3250_1720_2_1841_2" class="checkbox" value="1281"  />
                        </td>
                        <td><p>
                            <label for="3250_1720_2_1841_2" class="wrapable">Events</label>
                          </p></td>
                      </tr>
                      <tr valign="top" style="display:none;">
                        <td><input type="checkbox" name="3250_1720_2_1841" id="3250_1720_2_1841_3" class="checkbox" value="1282"  />
                        </td>
                        <td><p>
                            <label for="3250_1720_2_1841_3" class="wrapable">Exhibitions</label>
                          </p></td>
                      </tr>
                      <tr valign="top" style="display:none;">
                        <td><input type="checkbox" name="3250_1720_2_1841" id="3250_1720_2_1841_4" class="checkbox" value="1283"  />
                        </td>
                        <td><p>
                            <label for="3250_1720_2_1841_4" class="wrapable">For Educators</label>
                          </p></td>
                      </tr>
                      <tr valign="top" style="display:none;">
                        <td><input type="checkbox" name="3250_1720_2_1841" id="3250_1720_2_1841_5" class="checkbox" value="1284"  />
                        </td>
                        <td><p>
                            <label for="3250_1720_2_1841_5" class="wrapable">For Kids &amp; Families</label>
                          </p></td>
                      </tr>
                    </table>
                    <br />
                  </td>
                </tr>
                <tr valign="top">
                  <td width="5%" class="req" align="right" nowrap="nowrap">&nbsp;</td>
                  <td><span class="Explicit">Your Information</span>:<br />
                    <table border="0" cellspacing="4" cellpadding="0">
                      <tr style="position:absolute;left:-9999px">
                        <td colspan="3"><input type="hidden" name="cons_info_component" id="cons_info_component" value="t" />
                        </td>
                      </tr>
                      <tr>
                        <td width="1%"><p>*</p></td>
                        <td nowrap="nowrap"><p>
                            <label for="cons_email">Email: <span style="position:absolute;left:-9999px">Required</span></label>
                          </p></td>
                        <td><input type="text" name="cons_email" id="cons_email" value=""
size="15"
maxlength="255" />
                        </td>
                      </tr>
                      <tr style="display:none;">
                        <td width="1%"><p>&nbsp;</p></td>
                        <td colspan="2"><input type="hidden" name="cons_mail_opt_in" id="cons_mail_opt_in" value="t" />
                          <input type="checkbox" name="cons_email_opt_in" id="cons_email_opt_in" />
                          <label for="cons_email_opt_in" class="wrapable"> <span class="Explicit">Yes, I would like to receive email.</span></label>
                          <input type="hidden" id="cons_email_opt_in_requested" name="cons_email_opt_in_requested" value="true" />
                        </td>
                      </tr>
                    </table>
                    <br />
                  </td>
                </tr>
              </table>
            </div>
            <span style="display:none">
            <table border="0">
              <tr>
                <td><label for="denySubmit">Spam Control Text:</label>
                  &nbsp;
                  <input type="text" name="denySubmit" id="denySubmit" value="" 
alt="This field is used to prevent form submission by scripts." />
                  &nbsp;Please leave this field empty </td>
              </tr>
            </table>
            </span>
            <div class="appArea">
              <p>
                <input type="submit" name="ACTION_SUBMIT_SURVEY_RESPONSE" id="ACTION_SUBMIT_SURVEY_RESPONSE" value="Submit Survey" class="Button" />
                &nbsp;&nbsp; </p>
            </div>
            <input type="hidden" name="SURVEY_ID" id="SURVEY_ID" value="1720" />
          </form></td>
      </tr>
    </table>
	</div>
	<div id="footer">
		<p id="info">Bracero History Archive is a project of the <a href="http://chnm.gmu.edu">Center for History and New Media</a>, <a href="http://www.gmu.edu">George Mason University</a>, the <a href="http://americanhistory.si.edu">Smithsonian National Museum of American History</a>, <a href="http://brown.edu">Brown University</a>, and <a href="http://academics.utep.edu/Default.aspx?alias=academics.utep.edu/oralhistory">The Institute of Oral History</a> at the University of Texas at El Paso. Funding provided by the National Endowment for the Humanities.</p>
		<p id="copyright">&copy; <?php echo date(Y); ?>, Center for History and New Media</p>
<?php /*
		<a href="http://chnm.gmu.edu"><img src="<?php img('chnm2.gif'); ?>" /></a>			
		<a href="http://americanhistory.si.edu"><img src="<?php img('smithsonian.gif'); ?>" /></a>			
		<a href="http://brown.edu"><img src="<?php img('brown.gif'); ?>" /></a>			
		*/ ?>
	</div>
</body>
</html>
