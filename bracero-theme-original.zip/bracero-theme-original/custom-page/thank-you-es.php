<?php head(); ?>

<p>Gracias por su participación!</p>

<div id="return-home-button">
  <a href="<?php echo uri(''); ?>">Return Home</a> 
</div>

<?php foot(); ?>