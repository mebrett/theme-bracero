<?php head(); ?>
<h1>Partners</h1>
<h2>Site Partners</h2>
<h3>Center for History and New Media at George Mason University</h3>
<p>Since 1994 under the founding direction of Roy Rosenzweig, the Center for History and New Media (CHNM) at George Mason University has used digital media and computer technology to democratize history—to incorporate multiple voices, reach diverse audiences, and encourage popular participation in presenting and preserving the past.</p>

<p>CHNM uses digital media and technology to preserve and present history online, transform scholarship across the humanities, and advance historical education and understanding. Each year CHNM’s many project websites receive over 16 million visitors, and over a million people rely on its digital tools to teach, learn, and conduct research.</p>

<p>CHNM’s work has been recognized with major awards and grants from the American Historical Association, the National Humanities Center, the National Endowment for the Humanities, the Department of Education, the Library of Congress, the Institute of Museum and Library Services, the American Council of Learned Societies, and the Mellon, Sloan, Hewlett, Rockefeller, Gould, Delmas, and Kellogg foundations.</p>
<h3>Institute of Oral History at the University of Texas El Paso</h3>
<p>The Institute of Oral History at the University of Texas El Paso (IOH) was established in 1972 for the purpose of "preserving the history of the region adjacent to the Rio Grande both in the United States and in Mexico." Since that time, the Institute has built one of the largest border-related oral history collections in the United States. While an emphasis has been on the El Paso-Ciudad Juárez region, the collection also contains interviews dealing with the history of communities all along the U.S.-Mexico border. Current holdings include over 1000 interviews, representing over 1600 hours of tape recorded interviews and more than 20,000 pages of transcript. These materials cover a wide range of subjects, spanning social, economic, political, cultural and artistic concerns.</p>
<h3>Center for the Study of Race and Ethnicity in America at Brown University</h3>
<p>The Center for the Study of Race and Ethnicity in America (CSREA) was established in 1988 with the premise that is crucial to understand race as a historical and sociological reality in America and to understand the implications of race and ethnicity as historical, social, and analytical categories for mutidisciplinary studies and multiple modes of discourse. To coordinate and develop Brown`s academic resources for this purpose, the Center facilitates teaching and research on African Americans, Asian Americans, Latinos, and Native Americans. It also includes teaching, research, and conferences on biracials and multiracials.</p>

<p>The Center emphasizes the interdisciplinary and comparative study of these groups and promotes analytical studies of race, ethnicity, gender, and class. Within Brown University, the Center works with departments and faculty who share similar goals and interests. For graduate and undergraduate students, the Center brings in invited scholars and speakers for the annual events of ethnic student organizations and provides grants in support of their research in the areas of race and ethnicity in America or in the comparative study of American racial or ethnic groups with those in other countries.</p>


<h3>Smithsonian Institution's National Museum of American History</h3>
<p>The National Museum of American History (NMAH) opened to the public in January 1964 as the Museum of History and Technology. It was the sixth Smithsonian building on the National Mall in Washington, D.C. Since then, some 4 million visitors pass through the doors each year to enjoy the Museum’s exhibitions, public programs, educational activities, collections, and research facilities. Millions more make virtual visits to the Museum’s Web site.</p> 

<p>In 1980, the Museum's name was changed to the National Museum of American History to better represent its basic mission—the collection, care, and study of objects that reflect the experience of the American people. Today, the Museum is engaged in a major renovation to create a brighter and more open environment throughout the building and a dramatic new exhibition gallery for the Star-Spangled Banner.</p>
<h2>Virtual Partners</h2><p></p>
<h2>Collecting Partners</h2><p></p>
<h2>Community Partners</h2><p></p>

<?php foot(); ?>