<?php head(array('bodyid'=>'advanced-search')); ?>

	<div id="primary">
	
		<div id="search">
			<?php echo items_search_form(array('id'=>'search'), uri('items/browse'), false); ?>
		</div>
	</div>
<?php foot(); ?>