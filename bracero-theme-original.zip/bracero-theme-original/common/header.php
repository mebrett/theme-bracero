<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title><?php echo settings('site_title'); ?><?php if(!empty($title)) echo ' | '. $title; ?></title>

<!-- Meta -->
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="description" content="<?php echo settings('description'); ?>" />

<?php echo auto_discovery_link_tag(); ?>

<link rel="shortcut icon" href="<?php echo uri('/favicon.ico'); ?>" />

<!-- Stylesheets -->
<link rel="stylesheet" media="screen" href="<?php echo css('screen'); ?>" />
<link rel="stylesheet" media="print" href="<?php echo css('print'); ?>" />

<!--[if IE 6]>
	<link rel="stylesheet" media="screen" href="<?php echo css('ie6'); ?>" />
<![endif]-->

<!-- JavaScripts -->
<?php echo js('default'); ?>
<?php echo js('search'); ?>


<!-- Matomo -->
<script type="text/javascript">
  var _paq = window._paq || [];
  /* tracker methods like "setCustomDimension" should be called before "trackPageView" */
  _paq.push(['trackPageView']);
  _paq.push(['enableLinkTracking']);
  (function() {
    var u="//stats.rrchnm.org/";
    _paq.push(['setTrackerUrl', u+'matomo.php']);
    _paq.push(['setSiteId', '37']);
    var d=document, g=d.createElement('script'), s=d.getElementsByTagName('script')[0];
    g.type='text/javascript'; g.async=true; g.defer=true; g.src=u+'matomo.js'; s.parentNode.insertBefore(g,s);
  })();
</script>
<!-- End Matomo Code -->

</head>
<body<?php echo $bodyid ? ' id="'.$bodyid.'"' : ''; ?><?php echo $bodyclass ? ' class="'.$bodyclass.'"' : ''; ?>>	
	
		<div id="header">

			<div id="logo">
				<?php if($bodyclass=='home') { ?>
					<div class="padding">
					    <div id="award-button">
					       <img src="<?php echo img('Bracero-awardbadge.png'); ?>" />
					    </div>
				<?php } ?>
				<a id="logo-link" href="<?php echo uri(''); ?>"><img alt="Bracero Archive Logo" src="<?php if($bodyclass=='home') echo img('bracero-logo-lg.gif'); else echo img('bracero-logo.gif'); ?>" /></a>
				<?php if($bodyclass=='home') { ?>
				
				<div id="site-about">
					<p>The <em><?php echo settings('site_title'); ?></em> collects and makes available the oral histories and artifacts pertaining to the Bracero program, a guest worker initiative that spanned the years 1942-1964. Millions of Mexican agricultural workers crossed the border under the program to work in more than half of the states in America.</p>  
					
					<div id="buttons">
						<ul>
						<li><a href="<?php echo uri('items'); ?>">Browse the Archive</a></li>
						<!-- <li><a href="<?php echo uri(''); ?>">English</a></li> -->
						<li><a href="<?php echo uri('es')?>">Espa&ntilde;ol</a></li>
						</ul>
					</div>
				</div>
				

				
				
				<?php } if($bodyclass=='home') { ?>
					</div>
				<?php } ?>
			</div>			
			<div id="site-meta">
				<!-- <div id="login-status"> -->
                <?php// echo my_omeka_user_status(); ?>
				<!-- </div> -->
				

				<div id="search-box">
			    <?php echo simple_search(); ?>
			    <?php echo link_to_advanced_search(); ?>
				</div>

				

			</div>

		</div>
		
		<div id="sitenav">
			
			<ul>
				<?php echo nav(array('Archive' => uri('items'),'Teaching' => uri('teaching'),'History' => uri('history'),'Resources' => uri('resources'),'About' => uri('about'),'Partners'=>uri('partners'))); ?>
			</ul>
		</div>
		
		<div id="content">
