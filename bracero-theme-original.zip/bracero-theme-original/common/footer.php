	</div>
	<div id="footer">
    	
		<p id="info">Bracero History Archive is a project of the <a href="http://chnm.gmu.edu">Roy Rosenzweig Center for History and New Media</a>, <a href="http://www.gmu.edu">George Mason University</a>, the <a href="http://americanhistory.si.edu">Smithsonian National Museum of American History</a>, <a href="http://brown.edu">Brown University</a>, and <a href="http://academics.utep.edu/Default.aspx?alias=academics.utep.edu/oralhistory">The Institute of Oral History</a> at the University of Texas at El Paso. Funding provided by the National Endowment for the Humanities.</p>
		

		
		<p id="copyright">&copy; <?php echo date(Y); ?>, Center for History and New Media</p>
<?php /*
		<a href="http://chnm.gmu.edu"><img src="<?php img('chnm2.gif'); ?>" /></a>			
		<a href="http://americanhistory.si.edu"><img src="<?php img('smithsonian.gif'); ?>" /></a>			
		<a href="http://brown.edu"><img src="<?php img('brown.gif'); ?>" /></a>			
		*/ ?>
	</div>


    
<!-- START OF SmartSource Data Collector TAG -->
<!-- Copyright (c) 1996-2013 Webtrends Inc.  All rights reserved. -->
<!-- Version: 9.4.0 -->
<!-- Tag Builder Version: 4.1  -->
<!-- Created: 9/20/2013 6:49:03 PM -->
<script src="http://americanhistory.si.edu/_js/webtrends-bracero.js" type="text/javascript"></script>
<!-- ----------------------------------------------------------------------------------- -->
<!-- Warning: The two script blocks below must remain inline. Moving them to an external -->
<!-- JavaScript include file can cause serious problems with cross-domain tracking.      -->
<!-- ----------------------------------------------------------------------------------- -->
<script type="text/javascript">
//<![CDATA[
var _tag=new WebTrends();
_tag.dcsGetId();
//]]>
</script>
<script type="text/javascript">
//<![CDATA[
_tag.dcsCustom=function(){
// Add custom parameters here.
//_tag.DCSext.param_name=param_value;
_tag.WT.cg_n="histex";
}
_tag.dcsCollect();
//]]>
</script>
<noscript>
<div><img alt="DCSIMG" id="DCSIMG" width="1" height="1" src="//logs1.smithsonian.museum/dcs3cqzj3cdzpxzrcvl7q8cs0_5z1t/njs.gif?dcsuri=/nojavascript&amp;WT.js=No&amp;WT.tv=9.4.0&amp;dcssip=braceroarchive.org"/></div>
</noscript>
<!-- END OF SmartSource Data Collector TAG -->


    
</body>
</html>