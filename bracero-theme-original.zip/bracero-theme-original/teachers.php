<?php head(); ?>
<div id="primary">
	<h1>Teachers</h1>
</div>
<?php foot(); ?>