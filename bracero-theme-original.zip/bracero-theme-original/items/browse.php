<?php head(array('bodyclass'=>'archive','bodyid'=>'items-browse','title'=>'Archive')); ?>

	<div id="primary" class="browse">
		<div id="faceted-browse">
		<ul>
		<li><a href="<?php echo uri('items/browse/')?>" <?php if(!isset($_GET['type']) && !isset($_GET['advanced']['0']['element_id'])) echo ' class=current';?>>All</a></li>
		<li><a href="<?php echo uri('items/browse/?type=6'); ?>" <?php if($_GET['type'] == 6) echo ' class=current';?>>Images</a></li>
		<li><a href="<?php echo uri('items/browse/?type=1'); ?>" <?php if($_GET['type'] == 1) echo ' class=current';?>>Documents</a></li>
		<li><a href="<?php echo uri('items/browse/?type=4'); ?>" <?php if($_GET['type'] == 4) echo ' class=current';?>>Oral Histories</a></li>
		<li><a href="<?php echo uri('items/browse?search=&advanced[0][element_id]=42&advanced[0][type]=contains&advanced[0][terms]=Yes')?>" <?php if($_GET['advanced']['0']['element_id'] == 42) echo ' class=current';?>>Contributed Items</a></li>
		</ul>	
		</div>
		
		<?php /*?><div id="browse-search-box">
		<h3>Search</h3>
		<?php echo simple_search(array('id'=>'simple-search','name'=>'simple-search'),uri('items/browse')); ?>
		</div> <?php */ 
		
		?>
		
		<?php //items_search_form(array('id'=>'search_form'),uri('items/browse')); ?>
			<div id="pagination"><?php echo pagination_links(); ?></div>
			
		<h1>
			<?php if($_GET['type'] == 6): echo 'Browse Images';
				elseif ($_GET['type'] == 1): echo 'Browse Documents';
				elseif ($_GET['type'] == 4): echo 'Browse Oral Histories';
				elseif ($_GET['advanced']['0']['element_id'] == 42): echo 'Browse Contributed Items';
				else: echo 'Browse All';
				endif;
			?>
		    (<?php echo total_results();?> items total)
		</h1>
			
			<div id="item-list">
				<?php while (loop_items()): ?>
				<div class="item hentry<?php if(item('Contribution Form', 'Online Submission') == 'Yes') echo ' contributed-item'; ?>">
			
					<div class="item-meta">
					    
					<h2>					    
					    <?php if ($title = item('Dublin Core','Title')):  ?>
    					<?php echo link_to_item($title, array('class'=>'permalink')); ?>
    					<?php else: ?>
    					<?php echo link_to_item('Untitled'); ?>
    					<?php endif; ?>
					</h2>
					
					<?php if(item_has_thumbnail()): ?>
					<div class="item-img">
						<?php echo link_to_item(item_square_thumbnail()); ?>					
					</div>
					<?php endif; ?>
					

					<?php if($description = item('Dublin Core', 'Description')): ?>
					<div class="desc">
						<h3>Description:</h3>
					<?php echo $description; ?>
					</div>
					<?php endif; ?>

					<?php if(item_has_tags()): ?>
					<div class="tagcloud">
						<p><strong>Tags:</strong> 
                        <?php echo item_tags_as_string(); ?></p>
					</div>
					<?php endif;?>
					</p>
					</div>
					
					 <?php echo plugin_append_to_items_browse_each(); ?>

				</div>
				<?php endwhile;
				?>
				</div>
		</div>

<?php foot(); ?>