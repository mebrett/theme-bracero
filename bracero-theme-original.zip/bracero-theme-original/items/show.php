<?php head(array('bodyclass'=>'archive','title'=>'Item | ' .$title)); ?>

<div class="item-nav">
<?php echo link_to_previous_item('Previous Item',array('class'=>'previous')); ?>
<?php echo link_to_next_item('Next Item',array('class'=>'next')); ?>
</div>

<div id="primary">
    
    <?php if(item_has_type('Lesson Plan')): ?>

        <div class="lesson-plan">

        <h2><?php echo item('Dublin Core', 'Title'); ?></h2>

        <h3>Description</h3>
        <p><?php echo item('Dublin Core', 'Description'); ?></p>

        <h3>Duration</h3>
        <p><?php echo item('Item Type Metadata', 'Duration'); ?></p>


        <h3>Objectives</h3>
        <p><?php echo item('Item Type Metadata', 'Objectives'); ?></p>


        <h3>Materials</h3>
        <p><?php echo item('Item Type Metadata', 'Materials'); ?></p>


        <h3>Lesson Plan Text</h3>
        <p><?php echo item('Item Type Metadata', 'Lesson Plan Text'); ?></p>

        </div>


    <?php else: ?>


	<?php if($_GET['view'] == 'full'): ?>
		
		<a class="view-toggle" href="<?php echo uri('items/show/'.$item->id); ?>">Switch to Basic View</a>
		
		<h1><?php echo item('Dublin Core', "Title"); ?></h1>
		
		<?php if(item('Contribution Form', 'Online Submission') == 'Yes'): ?>
            <div id="contributed-item">
                <p>This item was contributed by a user and has not been curated by a project historian.</p>
            </div>
        <?php endif; ?>
		
		<?php if(item_has_thumbnail()): ?>
			<div id="fullsizeimg">
				<?php echo item_fullsize(); ?>
			</div>
		<?php endif; ?>
		
		<div id="item-images">
		<?php echo display_files($item->Files); ?>
		<?php foreach ($item->Files as $file): ?>
		<a href="<?php echo file_download_uri($file); ?>">Download <?php echo $file->original_filename; ?></a>
		<?php endforeach; ?>
		</div>
		
		
			<div id="description" class="field">
			<h3>Description</h3>
			<div>
			<?php echo display_empty(item('Dublin Core', 'Description')); ?>
			</div>
			</div>

			<div id="creator" class="field">
			<h3>Creator</h3>
			<div>
			<?php echo display_empty(item('Dublin Core', 'Creator')); ?>
			</div>
			</div>
			
			<?php /*
			<div id="additional_creator" class="field">
			<h3>Additional Creator</h3>
			<div>
			<?php echo display_empty(item('Additional Item Metadata', 'Additional Creator')); ?>
			</div>
			</div>
			*/ ?>
			

			<div id="date" class="field">
			<h3>Date</h3>
			<div>
			<?php echo display_empty(item('Dublin Core', 'Date'));?>
			</div>
			</div>

			<div id="citation" class="field">
			<h3>Bibliographic Citation</h3>
			<div>
			<p><?php echo item_citation();?></p>
			</div>
			</div>

			<div id="subject" class="field">
			<h3>Subject</h3>
			<div>
			<?php echo display_empty(item('Dublin Core', 'Subject')); ?>
			</div>
			</div>

			<div id="source" class="field">
			<h3>Source</h3>
			<div>
			<?php echo display_empty(item('Dublin Core', 'Source')); ?>
			</div>
			</div>

			<div id="publisher" class="field">
			<h3>Publisher</h3>
			<div>
			<?php echo display_empty(item('Dublin Core', 'Publisher')); ?>
			</div>
			</div>

			<div id="contributor" class="field">
			<h3>Contributor</h3>
			<div>
			<?php echo display_empty(item('Dublin Core', 'Contributor')); ?>
			</div>
			</div>

    			<div id="rights" class="field">
    			<h3>Rights</h3>
    			<div>
    			<?php echo display_empty(item('Dublin Core', 'Rights')); ?>
    			</div>
    			</div>

    			<div id="rights_holder" class="field">
    			<h3>Rights Holder</h3>
    			<div>
    			<?php echo display_empty(item('Additional Item Metadata', 'Rights Holder'))?>
    			</div>
    			</div>

    			<div id="relation" class="field">
    			<h3>Relation</h3>
    			<div>
    			<?php echo display_empty(item('Dublin Core', 'Relation')); ?>
    			</div>
    			</div>

    			<div id="spatial-coverage" class="field">
    			<h3>Spatial Coverage</h3>
    			<div>
    			<?php echo display_empty(item('Dublin Core', 'Coverage'))?>
    			</div>
    			</div>

    			<div id="language" class="field">
    			<h3>Language</h3>
    			<div>
    			<?php echo display_empty(item('Dublin Core', 'Language')); ?>
    			</div>
    			</div>


    			<div id="provenance" class="field">
    			<h3>Provenance</h3>
    			<div>
    			<?php echo display_empty(item('Additional Item Metadata', 'Provenance'))?>
    			</div>
    			</div>



    			<?php if (item_belongs_to_collection()): ?>
    			<div id="collection" class="field">
    			<h3>Collection</h3>
    			<div>
    				<p><?php echo link_to_collection_for_item(); ?></p>
    			</div>
    			</div>
    		    <?php endif; ?>

    			<div class="field">
    			<h3>Type Name</h3>
    				<div id="type_id" class="editableSelect"><?php echo item('Item Type Name') ?></div>
    			</div>

                    <?php $typeElements = item_type_elements(); ?>
        			<?php foreach($typeElements as $name => $value): ?>
        				<div class="field">
        					<h3><?php echo $name; ?></h3>
        					<div><?php if(!empty($value)) echo $value; else echo '<p>[Empty]</p>'; ?></div>
        				</div>
        			<?php endforeach; ?>


    		<h2>Tags</h2>

    			<div class="field">

    				<div id="tags">
    					<ul class="tags">
    						<?php if (item_has_tags()): ?>
    								<li class="tag">
    								<?php echo item_tags_as_string(); ?>
    							</li>
    						<?php endif; ?>
    					</ul>
    				</div>
    			</div>

				
			
			<?php else: ?>
				
			<a title="Click here to view all metadata" class="view-toggle" href="?view=full">Switch to Full View</a>
				
			<h1><?php echo item('Dublin Core', 'Title'); ?></h1>
			
    		<?php if(item('Contribution Form', 'Online Submission') == 'Yes'): ?>
                <div id="contributed-item">
                    <p>This item was contributed by a user and has not been curated by a project historian.</p>
                </div>
            <?php endif; ?>
			
		<?php if (item_has_thumbnail()): ?>
			<div id="fullsizeimg">
				<?php echo item_fullsize(); ?>
			</div>	
		<?php endif; ?>
		
		<div id="item-images">
		<?php echo display_files($item->Files); ?>
		<?php foreach ($item->Files as $file): ?>
		<a href="<?php echo file_download_uri($file); ?>">Download <?php echo $file->original_filename; ?></a>
		<?php endforeach; ?>
		</div>
		
		<div id="core-metadata" class="showitem">



		<div id="description" class="field">
		<h3>Description</h3>
		<div>
		<?php echo display_empty(item('Dublin Core', 'Description')); ?>
		</div>
		</div>
		
		<div id="document-text" class="field">
		<h3>Text</h3>
		<div>
		<?php echo display_empty(item('Item Type Metadata', 'Text')); ?>
		</div>
		</div>

		<div id="creator" class="field">
		<h3>Creator</h3>
		<div>
		<?php echo display_empty(item('Dublin Core', 'Creator')); ?>
		</div>
		</div>

        <?php /* 
		<div id="additional_creator" class="field">
		<h3>Additional Creator</h3>
		<div>
		<?php echo display_empty(item('Additional Item Metadata', 'Additional Creator')); ?>
		</div>
		</div>
		*/ ?>
		

		<div id="date" class="field">
		<h3>Date</h3>
		<div>
		<?php echo display_empty(item('Dublin Core', 'Date'));?>
		</div>
		</div>

		<div id="citation" class="field">
		<h3>Bibliographic Citation</h3>
		<div>
		<p><?php echo item_citation();?></p>
		</div>
		</div>

			
		</div>
		<?php endif; ?>
		
		<?php endif; ?>
		
		
		
</div><!-- end primary -->

	<?php echo plugin_append_to_items_show(); ?>
	
	<div class="item-nav">
	<?php echo link_to_previous_item('Previous Item',array('class'=>'previous')); ?>
	<?php echo link_to_next_item('Next Item',array('class'=>'next')); ?>
	</div>

<?php foot(); ?>
