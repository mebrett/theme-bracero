<?php head(); ?>
<h1>Tags</h1>

<?php tag_cloud($tags,uri('items/browse')); ?>

<?php foot(); ?>