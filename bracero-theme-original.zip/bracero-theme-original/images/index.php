<?php head(array('body_class'=>'home','title'=> 'Home')); ?>	

	<div id="primary">
	
		<h1>Coming Spring 2008</h1>

			<p>In a partnership between George Mason University&#8217;s <a href="http://chnm.gmu.edu">Center for History and New Media</a>, the <a href="http://americanhistory.si.edu/">National Museum of American History</a>, the <a href="http://www.utep.edu/">University of Texas at El Paso</a>, and <a href="http://brown.edu">Brown University</a>, <em><?php settings('site_title'); ?></em> will grow to include sound files and transcripts of interviews with program participants, photographs, documents, and other files of interest. Users, which will include researchers, students, and others interested in the Bracero program, will be able to conduct searches using several different fields.</p>	

	</div>
	<div id="contact-info" class="vcard">
		<p>Para mas información o para programar una entrevista en Oregon llame a al <span class="tel">971-244-8797</span>, en Arkansas llame a <span class="tel">870-275-4768</span>, or email us at <a href="mailto:info@braceroarchive.org" class="email">info@braceroarchive.org</a>.</p>
		<p>For more information about scheduling an interview in Oregon, please call <span class="tel">971-244-8797</span>, in Arkansas call <span class="tel">870-275-4768</span>, or email us at <a href="mailto:info@braceroarchive.org">info@braceroarchive.org</a>.</p>
	</div>
	
<?php foot(); ?>