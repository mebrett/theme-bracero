<?php head(array('title'=>'403')); ?>

<div id="primary">
<h1>Oops!</h1>

	<p>Sorry, you don't have permission to view this page.</p>
	
</div><!-- end primary -->

<?php foot(); ?>